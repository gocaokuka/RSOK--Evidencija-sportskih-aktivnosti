﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrezentacionaLogika
{
    public class clsPoslovnaPravila
    {
        private string pStringKonekcije;

        public clsPoslovnaPravila(string pStringKonekcije)
        {
            // TODO: Complete member initialization
            this.pStringKonekcije = pStringKonekcije;
        }


        internal bool DaLiImaMestaZaDodavanjeSporta(string IDLokacije)
        {
            throw new NotImplementedException();
        }
    }
}
